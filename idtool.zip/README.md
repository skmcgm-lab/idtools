# idtool
Static single-file tool for extracting ID and token pairs and converting to CSV.
Put this repository on GitHub and deploy with Vercel or Netlify.

Files:
- index.html : main web app
- vercel.json : rewrite root to index.html
- README.md : this file
